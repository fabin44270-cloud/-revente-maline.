# Revente Maline — projet APK Android

Application Android WebView embarquant l'interface HTML locale. Les données restent dans le stockage local WebView de l'appareil. Le sélecteur Android permet de choisir une photo. Les liens web s'ouvrent dans le navigateur.

## Générer l'APK sans Android Studio (GitHub Actions)

1. Crée un compte GitHub si nécessaire.
2. Crée un dépôt **public** nommé `revente-maline` sur GitHub.
3. Décompresse ce ZIP sur ton ordinateur et envoie **tout le contenu** du dossier dans le dépôt GitHub (y compris `.github/workflows/build-apk.yml`).
4. Ouvre l'onglet **Actions** du dépôt, choisis **Build Revente Maline APK**, puis **Run workflow**. Un premier build peut aussi démarrer automatiquement après l'envoi des fichiers sur la branche `main`.
5. Quand l'exécution est terminée avec une coche verte, ouvre l'exécution puis télécharge l'artefact **revente-maline-apk**.
6. Décompresse l'artefact téléchargé : le fichier `app-debug.apk` est l'APK à transférer sur ton téléphone Android.
7. Sur le téléphone, ouvre le fichier APK et autorise temporairement l'installation depuis cette source si Android le demande.

## Limites

- C'est une APK de débogage, non publiée sur Play Store et non signée avec une clé de publication personnelle.
- L'analyse automatique d'image et la récupération automatique des prix depuis les liens ne sont pas incluses ; les photos et liens sont joints/enregistrés pour une analyse manuelle.
- Les données sont stockées sur cet appareil. Utilise la fonction de sauvegarde de l'application pour conserver une copie.
